print('\033[33m' + '° :.　 . • ○ ° ★　 .　 *　.       '+'\033[0m'+'   ∧ ∧')
print('\033[33m' +'★ ° . .　　　　.　☾ °☆　 . * ● ¸ . '+'\033[0m'+'( - з -) ')
print('∩ │◥███◣ ╱◥███◣              ┏━〇〇━━━━━━━━━━━━━━━━━━┓')
print('╱◥◣ ◥████◣▓∩▓│∩ ║           ┃   허브마을에 오신것을 　  ┃')
print('│╱◥█◣║∩∩∩ ║◥█▓ ▓█◣          ┃  진심으로 환영합니다..☆ ┃')
print('││∩│ ▓ ║∩田│║▓ ▓ ▓∩ ║         ┗┳┳━━━━━━━━━━━━━━━━━━┳┳┛')
print('            　                  ┗┛ 　　　　　　        ┗┛')

import WWWPJ.login                  #lgoind 파일로 임폴트 하자
show_file = WWWPJ.login.Login()     #login 파일에 Login 클래스에 들어가자
show_file.show()                    #Ldogin 클래스에 show 함수를 보여주자

import WWWPJ.survay                #survay 파일로 임폴트 하자
show_file = WWWPJ.survay.Survey()   #survay 파일에 Survey 클래스에 들어가자
show_file.show()                    #Survey 클래스에 show 함수를 보여주자
